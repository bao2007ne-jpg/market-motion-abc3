const $ = (id) => document.getElementById(id);
let data = [];
let currentDay = 1;
let animationTimer = null;
let sliderTimer = null;
let requestNumber = 0;
let datasetVersion = 0;
let isPlaying = false;
let renderInProgress = false;

function formatPrice(value) {
  if (value === null || value === undefined || !Number.isFinite(Number(value))) return "—";
  return Number(value).toLocaleString("vi-VN", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function showError(message = "") {
  $("error").textContent = message;
}

async function updateChartImages() {
  const requestId = ++requestNumber;
  const day = currentDay;
  // Không thêm query ngẫu nhiên: ảnh đã tạo có thể được cache ở trình duyệt.
  const candleUrl = `/api/chart/candles/${day}.png?dataset=${datasetVersion}`;
  const lineUrl = `/api/chart/line/${day}.png?dataset=${datasetVersion}`;
  const [candleResponse, lineResponse] = await Promise.all([
    fetch(candleUrl, { cache: "force-cache" }),
    fetch(lineUrl, { cache: "force-cache" })
  ]);
  if (!candleResponse.ok || !lineResponse.ok) throw new Error("Không thể tạo biểu đồ từ dữ liệu hiện tại.");
  const [candleBlob, lineBlob] = await Promise.all([candleResponse.blob(), lineResponse.blob()]);
  // Bỏ qua kết quả cũ nếu người dùng đã chuyển sang phiên khác.
  if (requestId !== requestNumber) return;
  const oldCandle = $("candles").dataset.objectUrl;
  const oldLine = $("line").dataset.objectUrl;
  const newCandle = URL.createObjectURL(candleBlob);
  const newLine = URL.createObjectURL(lineBlob);
  $("candles").src = newCandle;
  $("line").src = newLine;
  $("candles").dataset.objectUrl = newCandle;
  $("line").dataset.objectUrl = newLine;
  if (oldCandle) URL.revokeObjectURL(oldCandle);
  if (oldLine) URL.revokeObjectURL(oldLine);
}

function updateMetrics() {
  const row = data[currentDay - 1];
  if (!row) return;
  $("day").textContent = `${currentDay} / ${data.length}`;
  $("open").textContent = formatPrice(row.open);
  $("close").textContent = formatPrice(row.close);
  $("daynum").textContent = currentDay;
  $("slider").value = currentDay;
  $("progress").textContent = `${currentDay} / ${data.length} phiên`;
}

function updateTable() {
  const rows = data.slice(0, 100);
  $("tbody").innerHTML = rows.map(row => `
    <tr><td>${row.day}</td><td>${formatPrice(row.open)}</td><td>${formatPrice(row.high)}</td>
    <td>${formatPrice(row.low)}</td><td>${formatPrice(row.close)}</td><td>${formatPrice(row.ref)}</td>
    <td>${formatPrice(row.floor)}</td><td>${formatPrice(row.ceil)}</td></tr>`).join("");
  if (data.length > 100) {
    $("tbody").insertAdjacentHTML("beforeend", `<tr><td colspan="8">Bảng xem nhanh 100 phiên đầu tiên. Tải CSV đã xử lý để xem toàn bộ dữ liệu.</td></tr>`);
  }
}

async function renderWebsite() {
  if (!data.length) return;
  updateMetrics();
  try {
    await updateChartImages();
    showError();
  } catch (error) {
    showError(error.message);
    throw error;
  }
}

async function goToDay(day) {
  if (!data.length) return;
  currentDay = Math.max(1, Math.min(data.length, Number(day) || 1));
  updateMetrics();
  await renderWebsite();
}

function stopAnimation() {
  isPlaying = false;
  if (animationTimer !== null) {
    clearTimeout(animationTimer);
    animationTimer = null;
  }
}

$("csv").addEventListener("change", async (event) => {
  const file = event.target.files[0];
  if (!file) return;
  stopAnimation();
  showError();
  const form = new FormData();
  form.append("csv", file);
  try {
    const response = await fetch("/api/upload", { method: "POST", body: form });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || "Không đọc được tệp CSV.");
    data = result.data;
    datasetVersion += 1;
    currentDay = 1;
    $("filename").textContent = result.filename;
    $("caption").textContent = `Tệp ${result.filename} · ${result.count} phiên`;
    $("count").textContent = `${result.count} phiên`;
    $("slider").max = result.count;
    $("slider").disabled = false;
    updateTable();
    await renderWebsite();
  } catch (error) {
    showError(error.message);
  }
});

$("play").addEventListener("click", async () => {
  if (!data.length) { showError("Hãy chọn tệp CSV trước."); return; }
  stopAnimation();
  if (currentDay >= data.length) currentDay = 1;
  isPlaying = true;

  const playNext = async () => {
    if (!isPlaying) return;
    if (currentDay >= data.length) { stopAnimation(); return; }
    try {
      // Chờ biểu đồ phiên hiện tại tải xong rồi mới sang phiên tiếp theo.
      await goToDay(currentDay + 1);
    } catch (_) {
      stopAnimation();
      return;
    }
    if (!isPlaying) return;
    animationTimer = setTimeout(playNext, Number($("speed").value));
  };

  try {
    await renderWebsite();
    if (isPlaying) animationTimer = setTimeout(playNext, Number($("speed").value));
  } catch (_) {
    stopAnimation();
  }
});

$("pause").addEventListener("click", stopAnimation);
$("reset").addEventListener("click", async () => {
  stopAnimation();
  clearTimeout(sliderTimer);
  try { await goToDay(1); } catch (_) {}
});

$("slider").addEventListener("input", (event) => {
  stopAnimation();
  currentDay = Math.max(1, Math.min(data.length, Number(event.target.value) || 1));
  updateMetrics();
  clearTimeout(sliderTimer);
  // Chỉ tạo biểu đồ sau khi người dùng ngừng kéo một chút.
  sliderTimer = setTimeout(() => renderWebsite(), 180);
});

$("speed").addEventListener("change", () => {
  if (isPlaying) $("play").click();
});

$("download").addEventListener("click", () => {
  if (!data.length) { showError("Chưa có dữ liệu để tải."); return; }
  window.location.href = "/api/download";
});
