# Market Motion ABC 3

Website mô phỏng giá cổ phiếu bằng Python, NumPy, pandas, Matplotlib và Flask.

## Cách đưa mã lên GitHub

1. Đăng nhập https://github.com/new và tạo repository tên `market-motion-abc3`.
2. Chọn **Public**, sau đó **Create repository**.
3. Chọn **uploading an existing file** hoặc **Add file → Upload files**.
4. Giải nén gói dự án. Tải **các tệp và thư mục bên trong** lên, không chỉ tải tệp ZIP.
5. Kiểm tra `app.py`, `requirements.txt`, `gunicorn.conf.py` và `render.yaml` nằm ngay ở gốc repository, cùng thư mục `static` và `templates`.
6. Chọn **Commit changes**. Mã nguồn đã công khai, nhưng lúc này ứng dụng Python chưa có máy chủ chạy.

## Chạy website công khai từ repository GitHub

GitHub Pages không chạy máy chủ Flask. Dự án này được chuẩn bị để triển khai trên Render, giữ nguyên cách Python tạo biểu đồ.

1. Đăng nhập https://dashboard.render.com/ bằng tài khoản của bạn.
2. Chọn **New → Web Service**, kết nối repository `market-motion-abc3`.
3. Chọn nhánh `main`; nếu tải đúng cấu trúc trên thì để trống **Root Directory**.
4. Nhập:
   - Language: **Python 3**.
   - Build Command: `pip install -r requirements.txt`.
   - Start Command: `gunicorn --config gunicorn.conf.py app:app`.
   - Instance Type: **Free**, nếu giao diện tài khoản cung cấp lựa chọn này.
5. Thêm biến môi trường `PYTHON_VERSION=3.12.12` và `MPLCONFIGDIR=/tmp/matplotlib`.
6. Chọn **Deploy Web Service** và chờ trạng thái **Live**.
7. Mở địa chỉ HTTPS `.onrender.com` mà Render cấp. Chọn tệp `abc-3.csv` để chạy mô phỏng.

Cách khác: chọn **New → Blueprint**, kết nối repository rồi sử dụng `render.yaml`; tệp này đã chọn gói `free`.

**Hai đường dẫn khác nhau:** địa chỉ `github.com/...` dùng để xem/tải mã nguồn; địa chỉ `.onrender.com` dùng để mở website hoạt động.

## Kiểm tra sau khi triển khai

- Trang chủ tải đủ giao diện và định dạng.
- Tải `abc-3.csv`, bảng báo 365 ngày.
- Hai biểu đồ xuất hiện, thanh trượt và nút chạy/tạm dừng hoạt động.
- Nút tải CSV trả về dữ liệu đã xử lý.

## Hiện trạng ứng dụng

Phần xử lý dữ liệu và giao diện được giữ nguyên từ ZIP được cung cấp. Gói này bổ sung cấu hình máy chủ Gunicorn, cấu hình triển khai Render và hướng dẫn GitHub.

Ứng dụng gốc lưu một bộ dữ liệu chung trong bộ nhớ máy chủ: người mở website có thể thấy bộ dữ liệu vừa được người khác tải lên; không dùng bản này để tải dữ liệu riêng tư. Bộ nhớ và dữ liệu tải lên được đặt lại khi máy chủ khởi động lại. Một worker được cấu hình để các yêu cầu đọc cùng vùng bộ nhớ. Bản này thích hợp trình diễn bộ ABC 3 công khai.

Gói Free có thể tạm dừng khi không hoạt động; lần mở lại có thể chờ khởi động. Nếu cần sử dụng đa người dùng với dữ liệu riêng, cần bổ sung tách phiên và nơi lưu dữ liệu trước khi triển khai cho mục đích đó.

## Chạy cục bộ

```sh
python -m pip install -r requirements.txt
python app.py
```

Mở http://127.0.0.1:5000. Trên Windows, chạy `python app.py`; Gunicorn dùng cho máy chủ Linux khi triển khai.

## Tài liệu chính thức

- https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site
- https://render.com/docs/deploy-flask
- https://render.com/docs/blueprint-spec
- https://render.com/docs/free
