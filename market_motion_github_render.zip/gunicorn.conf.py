"""Cau hinh web server. Dung mot worker vi app luu DATA trong RAM."""
import os
bind = "0.0.0.0:" + os.environ.get("PORT", "5000")
workers = 1
threads = 1
timeout = 120
accesslog = "-"
errorlog = "-"
