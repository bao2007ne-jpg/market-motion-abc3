# Market Motion — mô phỏng biến động giá cổ phiếu

Website giữ giao diện tiếng Việt và dùng Python xử lý dữ liệu, vẽ biểu đồ:

- **pandas** đọc CSV, tổ chức bảng giá và xuất dữ liệu đã xử lý.
- **NumPy** xử lý mảng giá và tìm giá trị lớn nhất/nhỏ nhất.
- **Matplotlib** tạo ảnh biểu đồ nến và biểu đồ đường theo từng phiên.
- **Flask** cung cấp API để giao diện web gửi CSV và nhận ảnh biểu đồ.
- HTML/CSS/JavaScript chỉ phụ trách giao diện và điều khiển animation; biểu đồ không còn được vẽ bằng Plotly.js.

## Chạy trên Windows bằng VS Code

1. Giải nén thư mục dự án và mở đúng thư mục `market_motion_website_python_final` trong VS Code.
2. Mở **Terminal → New Terminal** và chạy lần lượt:

```powershell
py -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements.txt
python app.py
```

3. Khi Terminal báo máy chủ đang chạy, mở trình duyệt tại `http://127.0.0.1:5000`.
4. Nhấn **Chọn tệp CSV** và chọn `abc-3.csv`. Không mở `index.html` bằng Live Server (cổng 5500/5501), vì phiên bản này cần Flask chạy phía Python.

## Cấu trúc CSV đang được giả định

Tệp cần có 7 cột số và mỗi dòng là một phiên giao dịch. Cột 1 là giá mở cửa; cột 7 là giá đóng cửa; 5 giá trị giữa cùng hai giá trị đầu/cuối được dùng để tính `high = max(7 giá trị)` và `low = min(7 giá trị)`. Giá tham chiếu bằng giá đóng cửa của phiên liền trước; giá sàn/trần bằng 90%/110% giá tham chiếu. Phiên đầu tiên không có giá tham chiếu.

Màu các mức giá được gán theo yêu cầu: giá bằng sàn màu xanh dương; bằng trần màu tím; bằng tham chiếu màu vàng; thấp hơn tham chiếu màu đỏ; cao hơn tham chiếu màu xanh lá. Do CSV không có cột ngày lịch, trục ngang dùng số thứ tự phiên.

**Quan trọng:** hãy xác nhận quy ước bảy cột với đề bài/giảng viên. Đây là mô phỏng học tập, không phải dữ liệu thị trường trực tiếp hay tư vấn đầu tư.
