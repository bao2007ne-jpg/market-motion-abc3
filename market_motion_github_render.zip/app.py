from functools import lru_cache
from io import BytesIO
from threading import Lock

from flask import Flask, jsonify, render_template, request, Response
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle

app = Flask(__name__)

# Dữ liệu hiện hành được lưu trong bộ nhớ của máy chủ.
DATA = None
SOURCE_NAME = ""
MATPLOTLIB_LOCK = Lock()

BG = "#081728"
TEXT = "#a9bdd7"
GRID = "#20334a"
GREEN = "#14c784"
RED = "#ff4565"
YELLOW = "#ffd43b"
BLUE = "#2589ff"
PURPLE = "#c34cff"


def load_stock_csv(file_obj):
    """Đọc CSV 7 cột: mở cửa, 5 mức giá tiếp theo, đóng cửa."""
    raw = pd.read_csv(file_obj, header=None, skip_blank_lines=True)
    if raw.empty:
        raise ValueError("Tệp CSV không có dữ liệu.")
    if raw.shape[1] != 7:
        raise ValueError(
            f"CSV cần đúng 7 cột giá; hiện tìm thấy {raw.shape[1]} cột. "
            "Hãy kiểm tra dấu phân cách của tệp."
        )

    numeric = raw.apply(pd.to_numeric, errors="coerce")
    # Cho phép một dòng tiêu đề ở đầu tệp.
    if numeric.iloc[0].isna().any():
        numeric = numeric.iloc[1:]
    if numeric.empty:
        raise ValueError("Không tìm thấy dòng dữ liệu số trong CSV.")
    if numeric.isna().any().any():
        bad_row = int(np.where(numeric.isna().any(axis=1))[0][0]) + 1
        raise ValueError(f"Dữ liệu có ô trống hoặc không phải số gần dòng {bad_row}.")

    values = numeric.to_numpy(dtype=float)
    if not np.isfinite(values).all():
        raise ValueError("Dữ liệu có giá trị không hữu hạn.")
    if (values < 0).any():
        raise ValueError("Dữ liệu giá không được âm.")

    frame = pd.DataFrame(values, columns=[f"price_{i}" for i in range(1, 8)])
    frame.insert(0, "day", np.arange(1, len(frame) + 1))
    frame["open"] = frame["price_1"]
    frame["close"] = frame["price_7"]
    frame["high"] = frame[[f"price_{i}" for i in range(1, 8)]].max(axis=1)
    frame["low"] = frame[[f"price_{i}" for i in range(1, 8)]].min(axis=1)
    frame["ref"] = frame["close"].shift(1)
    frame["floor"] = frame["ref"] * 0.9
    frame["ceil"] = frame["ref"] * 1.1
    return frame


def price_color(price, ref, floor=None, ceil=None):
    """Màu theo quy tắc đề bài; dùng tolerance để tránh sai số float."""
    if pd.isna(ref):
        return GREEN
    tol = max(abs(float(ref)) * 1e-7, 1e-6)
    if floor is not None and not pd.isna(floor) and abs(price - floor) <= tol:
        return BLUE
    if ceil is not None and not pd.isna(ceil) and abs(price - ceil) <= tol:
        return PURPLE
    if abs(price - ref) <= tol:
        return YELLOW
    return RED if price < ref else GREEN


def setup_axis(ax):
    ax.set_facecolor(BG)
    ax.tick_params(colors=TEXT, labelsize=8)
    ax.xaxis.label.set_color(TEXT)
    ax.yaxis.label.set_color(TEXT)
    ax.title.set_color("#eef5ff")
    for spine in ax.spines.values():
        spine.set_color("#37516f")
    ax.grid(True, color=GRID, linewidth=0.65, alpha=0.8)
    ax.set_axisbelow(True)


def fig_to_png(fig):
    output = BytesIO()
    # Xuất ảnh ở độ phân giải phù hợp cho web; tránh bước bbox_inches="tight"
    # vốn phải đo lại toàn bộ bố cục ở mỗi lần vẽ.
    fig.savefig(output, format="png", dpi=75, facecolor=fig.get_facecolor(),
                bbox_inches=None, pad_inches=0)
    plt.close(fig)
    output.seek(0)
    return output.getvalue()


def make_candles(day):
    d = DATA.iloc[max(0, day - 30):day]
    fig, ax = plt.subplots(figsize=(7.8, 3.35), dpi=105)
    fig.patch.set_facecolor("#0c1a2c")
    setup_axis(ax)

    for _, row in d.iterrows():
        x = int(row["day"])
        ref = row["ref"]
        floor = row["floor"]
        ceil = row["ceil"]
        color = price_color(float(row["close"]), ref, floor, ceil)
        ax.vlines(x, row["low"], row["high"], color=color, linewidth=1.15, zorder=2)
        bottom = min(row["open"], row["close"])
        height = abs(row["close"] - row["open"])
        # Thân nến có chiều cao tối thiểu để dễ quan sát, không thay đổi dữ liệu/râu nến.
        min_body = max((DATA["high"].max() - DATA["low"].min()) * 0.0015, 0.01)
        if height < min_body:
            bottom = (row["open"] + row["close"]) / 2 - min_body / 2
            height = min_body
        ax.add_patch(Rectangle((x - 0.29, bottom), 0.58, height,
                               facecolor=color, edgecolor=color, linewidth=0.8, zorder=3))

    ax.set_xlim(max(0.5, day - 30), day + 1)
    visible_low = float(d["low"].min())
    visible_high = float(d["high"].max())
    spread = max(visible_high - visible_low, abs(visible_high) * 0.02, 1)
    ax.set_ylim(visible_low - spread * 0.08, visible_high + spread * 0.08)
    ax.set_xlabel("Phiên giao dịch")
    ax.set_ylabel("Giá")
    ax.set_title(f"Biểu đồ nến · 30 phiên gần nhất · Phiên {day}/{len(DATA)}", loc="left", fontsize=9)
    fig.tight_layout(pad=1.1)
    return fig_to_png(fig)


def make_line_chart(day):
    visible = DATA.iloc[:day]
    fig, ax = plt.subplots(figsize=(7.8, 3.35), dpi=105)
    fig.patch.set_facecolor("#0c1a2c")
    setup_axis(ax)

    # Mỗi ngày gồm 7 mức giá; đặt các điểm cách đều nhau trong phiên.
    xs, ys, point_colors = [], [], []
    for _, row in visible.iterrows():
        ref = row["ref"]
        floor = row["floor"]
        ceil = row["ceil"]
        for j in range(1, 8):
            xs.append(float(row["day"]) + (j - 1) / 7)
            val = float(row[f"price_{j}"])
            ys.append(val)
            point_colors.append(price_color(val, ref, floor, ceil))

    x_arr = np.asarray(xs, dtype=float)
    y_arr = np.asarray(ys, dtype=float)
    if len(x_arr):
        ax.plot(x_arr, y_arr, color="#7695b8", linewidth=1.05, alpha=0.75, zorder=2)
        ax.scatter(x_arr, y_arr, c=point_colors, s=8, linewidths=0, zorder=3)
        ax.fill_between(x_arr, y_arr, 0, color=GREEN, alpha=0.045, zorder=1)

        max_idx = int(np.argmax(y_arr))
        min_idx = int(np.argmin(y_arr))
        max_val = float(y_arr[max_idx])
        min_val = float(y_arr[min_idx])
        ax.axhline(max_val, color=GREEN, linestyle=":", linewidth=1.1, alpha=0.8)
        ax.axhline(min_val, color=RED, linestyle=":", linewidth=1.1, alpha=0.8)
        ax.annotate(f"Max {max_val:,.0f}", (x_arr[max_idx], max_val),
                    xytext=(5, 5), textcoords="offset points", color=GREEN, fontsize=7)
        ax.annotate(f"Min {min_val:,.0f}", (x_arr[min_idx], min_val),
                    xytext=(5, -11), textcoords="offset points", color=RED, fontsize=7)

    latest = DATA.iloc[day - 1]
    if not pd.isna(latest["ref"]):
        for key, color, label in [
            ("ref", YELLOW, "Tham chiếu"),
            ("floor", BLUE, "Giá sàn"),
            ("ceil", PURPLE, "Giá trần"),
        ]:
            ax.axhline(float(latest[key]), color=color, linestyle="--", linewidth=0.9, alpha=0.8)

    ax.set_xlim(1, max(10, len(DATA)))
    all_min = float(DATA["low"].min())
    all_max = float(DATA["high"].max())
    pad = max((all_max - all_min) * 0.06, 1)
    ax.set_ylim(max(0, all_min - pad), all_max + pad)
    ax.set_xlabel("Phiên giao dịch")
    ax.set_ylabel("Giá")
    ax.set_title(f"Diễn biến giá và Max/Min · {day}/{len(DATA)} phiên", loc="left", fontsize=9)
    fig.tight_layout(pad=1.1)
    return fig_to_png(fig)


@app.route("/")
def index():
    return render_template("index.html")


@app.post("/api/upload")
def upload_csv():
    global DATA, SOURCE_NAME
    uploaded = request.files.get("csv")
    if uploaded is None or not uploaded.filename:
        return jsonify(error="Bạn hãy chọn tệp CSV trước."), 400
    try:
        new_data = load_stock_csv(uploaded)
        DATA = new_data
        SOURCE_NAME = uploaded.filename
        clear_chart_cache()
        return jsonify(filename=SOURCE_NAME, count=len(DATA), data=table_rows())
    except Exception as exc:
        return jsonify(error=str(exc)), 400


def table_rows():
    rows = []
    for _, r in DATA.iterrows():
        rows.append({
            "day": int(r["day"]), "open": float(r["open"]),
            "high": float(r["high"]), "low": float(r["low"]),
            "close": float(r["close"]),
            "ref": None if pd.isna(r["ref"]) else float(r["ref"]),
            "floor": None if pd.isna(r["floor"]) else float(r["floor"]),
            "ceil": None if pd.isna(r["ceil"]) else float(r["ceil"]),
        })
    return rows


@lru_cache(maxsize=120)
def cached_chart(kind, day, dataset_version):
    # Matplotlib không đảm bảo an toàn khi nhiều request vẽ cùng lúc.
    # Khóa này tránh hai biểu đồ đè lên trạng thái đồ họa toàn cục.
    with MATPLOTLIB_LOCK:
        if kind == "candles":
            return make_candles(day)
        return make_line_chart(day)


def clear_chart_cache():
    cached_chart.cache_clear()


@app.get("/api/chart/<kind>/<int:day>.png")
def chart(kind, day):
    if DATA is None:
        return "Chưa tải dữ liệu CSV.", 400
    if kind not in ("candles", "line"):
        return "Loại biểu đồ không hợp lệ.", 404
    day = max(1, min(day, len(DATA)))
    # Dùng tên tệp + số dòng làm khóa phiên bản sau mỗi lần upload.
    png = cached_chart(kind, day, f"{SOURCE_NAME}:{len(DATA)}")
    return Response(png, mimetype="image/png", headers={"Cache-Control": "public, max-age=3600"})


@app.get("/api/download")
def download_csv():
    if DATA is None:
        return "Chưa tải dữ liệu CSV.", 400
    out = pd.DataFrame({
        "Ngay": DATA["day"], "Gia_mo_cua": DATA["open"],
        "Gia_cao_nhat": DATA["high"], "Gia_thap_nhat": DATA["low"],
        "Gia_dong_cua": DATA["close"], "Gia_tham_chieu": DATA["ref"],
        "Gia_san": DATA["floor"], "Gia_tran": DATA["ceil"],
    })
    content = "\ufeff" + out.to_csv(index=False, lineterminator="\n")
    return Response(content, mimetype="text/csv; charset=utf-8",
                    headers={"Content-Disposition": "attachment; filename=du_lieu_chung_khoan_da_xu_ly.csv"})


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
